namespace Api.Funcionalidades.Productos;

public class ProductoDto
{
    public required string Nombre{ get; set; }
    public required double Precio{ get; set; }
    public required int Stock{ get; set; }

}
