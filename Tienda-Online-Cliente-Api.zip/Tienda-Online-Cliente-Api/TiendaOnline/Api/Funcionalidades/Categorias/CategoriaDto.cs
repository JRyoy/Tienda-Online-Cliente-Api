namespace Api.Funcionalidades.Categorias;

public class CategoriaDto
{
    public required string Nombre{get; set;}
    public required string Descripcion{get; set;}= string.Empty;
    
}
